// حاليًا لا يوجد سلوك ديناميكي
console.log("مرحبا بك في AMO Accessories");